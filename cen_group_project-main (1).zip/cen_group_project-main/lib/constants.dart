import 'package:flutter/material.dart';

import 'dart:ui';

const kPrimaryColor = Color(0xFF512DA8);
const kPrimaryLightColor = Color(0xFF9575CD);
