package com.example.cen_group_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
